# Photo Upload Route Pattern

Add this tRPC route to allow users to upload existing photos to the gallery for use in print layouts.

```ts
// In server/routers.ts, inside the images router:
upload: protectedProcedure
  .input(z.object({
    imageDataUrl: z.string().min(1), // base64 data URL
    fileName: z.string().default("uploaded-image"),
    prompt: z.string().default("Uploaded image"),
  }))
  .mutation(async ({ ctx, input }) => {
    const userId = ctx.user.id;
    
    // Parse the base64 data URL
    const matches = input.imageDataUrl.match(/^data:([^;]+);base64,(.+)$/);
    if (!matches) throw new Error("Invalid image data URL");
    
    const contentType = matches[1];
    const base64Data = matches[2];
    const buffer = Buffer.from(base64Data, "base64");
    
    // Determine file extension
    const ext = contentType.includes("png") ? "png" : contentType.includes("webp") ? "webp" : "jpg";
    const s3Key = `images/${userId}/upload-${nanoid()}.${ext}`;
    
    // Upload to S3
    const { url: s3Url } = await storagePut(s3Key, buffer, contentType);
    
    // Create the image record in DB
    const imageId = await db.createGeneratedImage({
      userId,
      taskId: `upload-${nanoid()}`,
      prompt: input.prompt || input.fileName,
      originalTopic: "Uploaded",
      model: "uploaded",
      aspectRatio: "1:1",
      resolution: "1K",
      status: "completed",
      imageUrl: s3Url,
      s3Key,
    });
    
    return { id: imageId, imageUrl: s3Url };
  }),
```

## Frontend Upload Handler

```tsx
// Hidden file input + upload mutation in Gallery page
const fileInputRef = useRef<HTMLInputElement>(null);
const uploadMutation = trpc.images.upload.useMutation({
  onSuccess: () => {
    utils.images.list.invalidate();
    toast.success("Photo uploaded to gallery!");
  },
  onError: (err) => toast.error(err.message),
});

const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
  const files = e.target.files;
  if (!files?.length) return;

  for (const file of Array.from(files)) {
    if (!file.type.startsWith("image/")) {
      toast.error(`${file.name} is not an image`);
      continue;
    }
    if (file.size > 10 * 1024 * 1024) {
      toast.error(`${file.name} exceeds 10MB limit`);
      continue;
    }
    const reader = new FileReader();
    reader.onload = () => {
      uploadMutation.mutate({
        imageDataUrl: reader.result as string,
        fileName: file.name,
        prompt: `Uploaded: ${file.name}`,
      });
    };
    reader.readAsDataURL(file);
  }
  e.target.value = "";
};

// In JSX:
<input
  ref={fileInputRef}
  type="file"
  accept="image/*"
  multiple
  className="hidden"
  onChange={handleFileUpload}
/>
<Button onClick={() => fileInputRef.current?.click()}>
  <Upload className="w-4 h-4 mr-2" /> Upload Photos
</Button>
```
