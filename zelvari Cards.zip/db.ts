  const db = await getDb();
  if (!db) return [];
  
  return db.select()
    .from(generatedImages)
    .where(and(eq(generatedImages.userId, userId), eq(generatedImages.status, "completed")))
    .orderBy(desc(generatedImages.createdAt))
    .limit(limit)
    .offset(offset);
}

export async function getFavoriteImages(userId: number): Promise<GeneratedImage[]> {
  const db = await getDb();
  if (!db) return [];
  
  return db.select()
    .from(generatedImages)
    .where(and(eq(generatedImages.userId, userId), eq(generatedImages.isFavorite, true)))
    .orderBy(desc(generatedImages.createdAt));
}

export async function toggleFavorite(id: number, userId: number): Promise<boolean> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const [image] = await db.select().from(generatedImages)
    .where(and(eq(generatedImages.id, id), eq(generatedImages.userId, userId)))