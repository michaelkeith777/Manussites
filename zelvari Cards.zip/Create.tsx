                        </div>
                        {/* Model label badge */}
                        {img.model && (
                          <div className={cn(
                            "absolute top-1 left-1 text-[10px] font-medium px-1.5 py-0.5 rounded-md backdrop-blur-sm",
                            img.model === "nano-banana" && "bg-purple-500/80 text-white",
                            img.model === "nano-banana-pro" && "bg-primary/80 text-white",
                            img.model === "grok-imagine" && "bg-blue-500/80 text-white",
                            img.model === "openai-4o" && "bg-green-500/80 text-white"
                          )}>
                            {img.model === "nano-banana" ? "Nano" : img.model === "nano-banana-pro" ? "Pro" : img.model === "grok-imagine" ? "Grok" : "OpenAI"}
                          </div>
                        )}
                      </motion.div>
                    ))}
                  </div>

                  {/* Timeout Warning */}
                  {showTimeoutWarning && (
                    <motion.div
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="p-4 rounded-lg bg-amber-500/10 border border-amber-500/30"
                    >
                      <div className="flex items-start gap-3">
                        <Clock className="w-5 h-5 text-amber-500 mt-0.5" />
                        <div className="flex-1">
                          <p className="font-medium text-amber-500">Taking longer than expected</p>
                          <p className="text-sm text-muted-foreground mt-1">
                            The AI is still working on your images. This can happen during high demand periods.
                          </p>
                          <div className="flex gap-2 mt-3">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => setShowTimeoutWarning(false)}
                            >
                              Continue Waiting
                            </Button>
                            <Button
                              variant="destructive"
                              size="sm"
                              onClick={handleCancelGeneration}
                            >
                              <XCircle className="w-4 h-4 mr-1" />
                              Cancel
                            </Button>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  )}

                  {/* Status Message and Refresh Button */}
                  <div className="flex items-center justify-between">
                    <p className="text-sm text-muted-foreground">
                      Please wait while the AI generates your sports card artwork...
                    </p>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={handleManualRefresh}
                      disabled={checkStatus.isFetching}
                    >
                      <RefreshCw className={cn("w-4 h-4 mr-1", checkStatus.isFetching && "animate-spin")} />
                      Refresh
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}

          {/* Step 5: Select & Download */}
          {step === 5 && (
            <motion.div
              key="step5"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="max-w-4xl mx-auto"
            >
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Download className="w-5 h-5 text-primary" />
                    Select & Download Your Cards
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {generatedImages
                      .filter((img) => img.status === "success" && img.imageUrl)
                      .map((img, index) => (
                        <motion.div
                          key={img.taskId}
                          initial={{ opacity: 0, scale: 0.9 }}
                          animate={{ opacity: 1, scale: 1 }}
                          transition={{ delay: index * 0.05 }}
                          className="relative group"
                        >
                          <button
                            onClick={() => handleToggleSelect(img.taskId)}
                            className={cn(
                              "w-full aspect-[2/3] rounded-lg overflow-hidden border-2 transition-all",
                              selectedImages.has(img.taskId)
                                ? "border-primary ring-2 ring-primary/20"
                                : "border-transparent hover:border-primary/50"
                            )}
                          >
                            <img
                              src={img.imageUrl}
                              alt={`Generated ${index + 1}`}
                              className="w-full h-full object-cover"
                            />
                            {selectedImages.has(img.taskId) && (
                              <div className="absolute top-2 right-2 w-6 h-6 rounded-full bg-primary flex items-center justify-center">
                                <Check className="w-4 h-4 text-primary-foreground" />
                              </div>
                            )}
                            {/* Model label badge */}
                            {img.model && (
                              <div className={cn(
                                "absolute top-2 left-2 text-[10px] font-semibold px-2 py-0.5 rounded-md backdrop-blur-sm shadow-sm",
                                img.model === "nano-banana" && "bg-purple-500/90 text-white",
                                img.model === "nano-banana-pro" && "bg-primary/90 text-white",
                                img.model === "grok-imagine" && "bg-blue-500/90 text-white",
                                img.model === "openai-4o" && "bg-green-500/90 text-white"
                              )}>
                                {img.model === "nano-banana" ? "Nano Banana" : img.model === "nano-banana-pro" ? "Nano Pro" : img.model === "grok-imagine" ? "Grok" : "OpenAI 4o"}
                              </div>
                            )}
                          </button>
                          {/* Edit button on hover */}
                          <div className="absolute bottom-2 left-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col gap-1">
                            <Button
                              size="sm"
                              variant="secondary"
                              className="w-full text-xs"
                              onClick={(e) => {
                                e.stopPropagation();
                                setEditingImageUrl(img.imageUrl || null);
                                setEditorOpen(true);
                              }}
                            >
                              <Crop className="w-3 h-3 mr-1" />
                              Edit & Crop
                            </Button>
                            <Button
                              size="sm"
                              variant="secondary"
                              className="w-full text-xs"
                              onClick={(e) => {
                                e.stopPropagation();
                                setWatermarkImageUrl(img.imageUrl || null);
                                setWatermarkOpen(true);
                              }}
                            >
                              <Type className="w-3 h-3 mr-1" />
                              Watermark
                            </Button>
                            <Button
                              size="sm"
                              variant="secondary"
                              className="w-full text-xs"
                              onClick={(e) => {
                                e.stopPropagation();
                                setExportImageUrl(img.imageUrl || null);
                                setExportImageName(`zelvari-card-${index + 1}`);
                                setExportOpen(true);
                              }}
                            >
                              <Download className="w-3 h-3 mr-1" />
                              Export
                            </Button>
                          </div>
                        </motion.div>
                      ))}
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">
                      {selectedImages.size} image{selectedImages.size !== 1 ? "s" : ""} selected
                    </span>
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        onClick={() => {
                          setStep(1);
                          setSelectedTopic(null);
                          setCustomTopic("");
                          setPrompt("");
                          setTaskIds([]);
                          setGeneratedImages([]);
                          setSelectedImages(new Set());
                        }}
                      >
                        <RefreshCw className="w-4 h-4 mr-2" />
                        Create More
                      </Button>
                      <Button
                        onClick={handleDownloadSelected}
                        disabled={selectedImages.size === 0}
                        className="glow-purple-sm"
                      >
                        <Download className="w-4 h-4 mr-2" />
                        Download Selected
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Image Editor Modal */}
        {editingImageUrl && (
          <ImageEditor
            imageUrl={editingImageUrl}
            isOpen={editorOpen}
            onClose={() => {
              setEditorOpen(false);
              setEditingImageUrl(null);
            }}
          />
        )}

        {/* Watermark Modal */}
        {watermarkImageUrl && (
          <Watermark
            imageUrl={watermarkImageUrl}
            isOpen={watermarkOpen}
            onClose={() => {
              setWatermarkOpen(false);
              setWatermarkImageUrl(null);
            }}
          />
        )}

        {/* Export Dialog */}
        {exportImageUrl && (
          <ExportDialog
            open={exportOpen}
            onOpenChange={(open) => {
              setExportOpen(open);
              if (!open) setExportImageUrl(null);
            }}
            imageUrl={exportImageUrl}
            imageName={exportImageName}
          />
        )}
      </div>
    </AppLayout>
  );
}
