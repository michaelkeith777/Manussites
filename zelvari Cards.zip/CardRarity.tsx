import { Sparkles, Star, Crown, Gem } from "lucide-react";

export type RarityLevel = "common" | "rare" | "epic" | "legendary";

interface CardRarityProps {
  rarity: RarityLevel;
  showLabel?: boolean;
  size?: "sm" | "md" | "lg";
  className?: string;
}

const rarityConfig = {
  common: {
    label: "Common",
    icon: Star,
    color: "text-gray-400",
    bgColor: "bg-gray-500/20",
    borderColor: "border-gray-500/50",
    gradient: "from-gray-400 to-gray-600",
  },
  rare: {
    label: "Rare",
    icon: Sparkles,
    color: "text-blue-400",
    bgColor: "bg-blue-500/20",
    borderColor: "border-blue-500/50",
    gradient: "from-blue-400 to-blue-600",
  },
  epic: {