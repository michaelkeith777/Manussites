import 'dotenv/config';

const apiKey = process.env.KIE_API_KEY;

async function testCreateTask() {
  console.log('Testing kie.ai API...');
  console.log('API Key present:', !!apiKey);
  console.log('API Key (first 10 chars):', apiKey?.substring(0, 10) + '...');
  
  // Create a test task
  const response = await fetch('https://api.kie.ai/api/v1/jobs/createTask', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      model: 'google/nano-banana',
      input: {
        prompt: 'A basketball player dunking',
        image_size: '2:3',
        output_format: 'png'
      }
    })
  });
  
  const data = await response.json();
  console.log('Create Task Response:', JSON.stringify(data, null, 2));
  
  if (data.data?.taskId) {
    console.log('\\nWaiting 10 seconds before checking status...');
    await new Promise(r => setTimeout(r, 10000));
    
    const statusResponse = await fetch(`https://api.kie.ai/api/v1/jobs/recordInfo?taskId=${data.data.taskId}`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      }
    });
    
    const statusData = await statusResponse.json();
    console.log('Task Status Response:', JSON.stringify(statusData, null, 2));
    
    // If still generating, wait more
    if (statusData.data?.state === 'generating' || statusData.data?.state === 'queuing') {
      console.log('\\nStill generating, waiting 15 more seconds...');
      await new Promise(r => setTimeout(r, 15000));
      
      const statusResponse2 = await fetch(`https://api.kie.ai/api/v1/jobs/recordInfo?taskId=${data.data.taskId}`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${apiKey}`,
          'Content-Type': 'application/json',
        }
      });
      
      const statusData2 = await statusResponse2.json();
      console.log('Final Task Status Response:', JSON.stringify(statusData2, null, 2));
    }
  }
}

testCreateTask().catch(console.error);
