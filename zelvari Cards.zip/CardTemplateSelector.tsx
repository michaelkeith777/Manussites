import { useState } from "react";
import { motion } from "framer-motion";
import { Check, Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";

export interface CardTemplate {
  id: string;
  name: string;
  description: string;
  previewUrl: string;
  frameUrl: string;
}

export const CARD_TEMPLATES: CardTemplate[] = [
  {
    id: "none",
    name: "No Frame",
    description: "Generate artwork without a card frame",
    previewUrl: "",
    frameUrl: "",
  },
  {
    id: "classic",
    name: "Classic",
    description: "Elegant golden frame with vintage styling",
    previewUrl: "/templates/classic-frame.png",
    frameUrl: "/templates/classic-frame.png",
  },
  {
    id: "fantasy",
    name: "Fantasy",
    description: "Magical frame with glowing runes and crystals",
    previewUrl: "/templates/fantasy-frame.png",
    frameUrl: "/templates/fantasy-frame.png",
  },
  {
    id: "scifi",
    name: "Sci-Fi",
    description: "Futuristic frame with holographic circuits",
    previewUrl: "/templates/scifi-frame.png",
    frameUrl: "/templates/scifi-frame.png",
  },
  {
    id: "sports",
    name: "Sports",
    description: "Championship-style frame for athletes",
    previewUrl: "/templates/sports-frame.png",
    frameUrl: "/templates/sports-frame.png",
  },
  {
    id: "anime",
    name: "Anime",
    description: "Kawaii frame with stars and hearts",
    previewUrl: "/templates/anime-frame.png",
    frameUrl: "/templates/anime-frame.png",
  },
  {
    id: "minimalist",
    name: "Minimalist",
    description: "Clean modern frame with simple lines",
    previewUrl: "/templates/minimalist-frame.png",
    frameUrl: "/templates/minimalist-frame.png",
  },
];

interface CardTemplateSelectorProps {
  selectedTemplate: string;
  onSelectTemplate: (templateId: string) => void;
  className?: string;
}

export function CardTemplateSelector({
  selectedTemplate,
  onSelectTemplate,
  className,
}: CardTemplateSelectorProps) {
  return (
    <div className={cn("space-y-3", className)}>
      <div className="flex items-center gap-2">
        <Sparkles className="h-4 w-4 text-primary" />
        <span className="text-sm font-medium">Card Frame Template</span>
      </div>
      
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
        {CARD_TEMPLATES.map((template) => (
          <motion.button
            key={template.id}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => onSelectTemplate(template.id)}
            className={cn(
              "relative group rounded-xl border-2 p-2 transition-all duration-200",
              "hover:border-primary/50 hover:bg-accent/50",
              selectedTemplate === template.id
                ? "border-primary bg-primary/10"
                : "border-border bg-card"
            )}
          >
            {/* Preview */}
            <div className="aspect-[3/4] rounded-lg overflow-hidden bg-muted/50 mb-2">
              {template.id === "none" ? (
                <div className="w-full h-full flex items-center justify-center">
                  <div className="text-center">
                    <div className="w-12 h-12 mx-auto rounded-lg bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center mb-2">
                      <Sparkles className="h-6 w-6 text-primary/50" />
                    </div>
                    <span className="text-xs text-muted-foreground">No Frame</span>
                  </div>
                </div>
              ) : (
                <img
                  src={template.previewUrl}
                  alt={template.name}
                  className="w-full h-full object-contain"
                />
              )}
            </div>

            {/* Info */}
            <div className="text-left">
              <h4 className="text-sm font-medium truncate">{template.name}</h4>
              <p className="text-xs text-muted-foreground line-clamp-1">
                {template.description}
              </p>
            </div>

            {/* Selected indicator */}
            {selectedTemplate === template.id && (
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                className="absolute top-1 right-1 w-5 h-5 rounded-full bg-primary flex items-center justify-center"
              >
                <Check className="h-3 w-3 text-primary-foreground" />
              </motion.div>
            )}
          </motion.button>
        ))}
      </div>
    </div>
  );
}

// Helper function to get template by ID
export function getTemplateById(id: string): CardTemplate | undefined {
  return CARD_TEMPLATES.find((t) => t.id === id);
}
