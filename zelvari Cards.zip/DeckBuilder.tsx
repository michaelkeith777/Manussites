import { useAuth } from "@/_core/hooks/useAuth";
import { AppLayout } from "@/components/AppLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import { cn } from "@/lib/utils";
import { motion, AnimatePresence } from "framer-motion";
import {
  Plus,
  Layers,
  Images,
  Loader2,
  Trash2,
  Edit,
  MoreVertical,
  Download,
  FileText,
  Grid3X3,
  Printer,
  X,
  GripVertical,
} from "lucide-react";
import { useState, useMemo } from "react";
import { toast } from "sonner";
import { Link } from "wouter";
import { getLoginUrl } from "@/const";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { jsPDF } from "jspdf";

interface Deck {
  id: number;
  name: string;
  description: string | null;
  cardCount: number;
  createdAt: Date;
}

interface DeckCard {
  id: number;
  imageUrl: string;
  prompt: string;
  position: number;
}

export default function DeckBuilder() {
  const { isAuthenticated, loading: authLoading } = useAuth();
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [editingDeck, setEditingDeck] = useState<Deck | null>(null);
  const [selectedDeck, setSelectedDeck] = useState<Deck | null>(null);
  const [newDeckName, setNewDeckName] = useState("");
  const [newDeckDescription, setNewDeckDescription] = useState("");
  const [addCardsDialogOpen, setAddCardsDialogOpen] = useState(false);
  const [selectedCardsToAdd, setSelectedCardsToAdd] = useState<Set<number>>(new Set());
  const [exportFormat, setExportFormat] = useState<"pdf-single" | "pdf-grid">("pdf-single");
  const [isExporting, setIsExporting] = useState(false);

  const utils = trpc.useUtils();

  // Queries
  const decksQuery = trpc.decks.list.useQuery(
    undefined,
    { enabled: isAuthenticated }
  );

  const deckCardsQuery = trpc.decks.getCards.useQuery(
    { deckId: selectedDeck?.id || 0 },
    { enabled: !!selectedDeck }
  );

  const galleryQuery = trpc.images.list.useQuery(
    { limit: 100 },
    { enabled: isAuthenticated && addCardsDialogOpen }
  );

  // Mutations
  const createDeck = trpc.decks.create.useMutation({
    onSuccess: () => {
      toast.success("Deck created!");
      utils.decks.list.invalidate();
      setCreateDialogOpen(false);
      resetForm();
    },
    onError: (error) => {
      toast.error(error.message || "Failed to create deck");
    },
  });

  // Note: Update deck functionality would need a backend route to be added
  // For now, we'll use delete + create as a workaround
  const updateDeckMutation = {
    mutate: async (data: { id: number; name: string; description?: string }) => {
      toast.info("Deck update coming soon");
      setEditingDeck(null);
      resetForm();
    },
    isPending: false,
  };

  const deleteDeck = trpc.decks.delete.useMutation({
    onSuccess: () => {
      toast.success("Deck deleted!");
      utils.decks.list.invalidate();
      if (selectedDeck) setSelectedDeck(null);
    },
    onError: (error) => {
      toast.error(error.message || "Failed to delete deck");
    },
  });

  const addCardsToDeck = trpc.decks.addCard.useMutation({
    onSuccess: () => {
      toast.success("Cards added to deck!");
      utils.decks.getCards.invalidate();
      utils.decks.list.invalidate();
      setAddCardsDialogOpen(false);
      setSelectedCardsToAdd(new Set());
    },
    onError: (error: { message?: string }) => {
      toast.error(error.message || "Failed to add cards");
    },
  });

  const removeCardFromDeck = trpc.decks.removeCard.useMutation({
    onSuccess: () => {
      toast.success("Card removed from deck!");
      utils.decks.getCards.invalidate();
      utils.decks.list.invalidate();
    },
    onError: (error) => {
      toast.error(error.message || "Failed to remove card");
    },
  });

  const resetForm = () => {
    setNewDeckName("");
    setNewDeckDescription("");
  };

  const handleCreate = () => {
    if (!newDeckName.trim()) {
      toast.error("Please enter a deck name");
      return;
    }
    createDeck.mutate({
      name: newDeckName.trim(),
      description: newDeckDescription.trim() || undefined,
    });
  };

  const handleUpdate = () => {
    if (!editingDeck || !newDeckName.trim()) {
      toast.error("Please enter a deck name");
      return;
    }
    updateDeckMutation.mutate({
      id: editingDeck.id,
      name: newDeckName.trim(),
      description: newDeckDescription.trim() || undefined,
    });
  };

  const handleDelete = (id: number) => {
    if (confirm("Are you sure you want to delete this deck?")) {
      deleteDeck.mutate({ id });
    }
  };

  const handleAddCards = async () => {
    if (!selectedDeck || selectedCardsToAdd.size === 0) return;
    // Add cards one by one since the API only supports single card addition
    const imageIds = Array.from(selectedCardsToAdd);
    for (const imageId of imageIds) {
      await addCardsToDeck.mutateAsync({
        deckId: selectedDeck.id,
        imageId,
      });
    }
  };

  const handleRemoveCard = (imageId: number) => {
    if (!selectedDeck) return;
    removeCardFromDeck.mutate({
      deckId: selectedDeck.id,
      imageId,
    });
  };

  const openEditDialog = (deck: Deck) => {
    setEditingDeck(deck);
    setNewDeckName(deck.name);
    setNewDeckDescription(deck.description || "");
  };

  const toggleCardSelection = (imageId: number) => {
    const newSelection = new Set(selectedCardsToAdd);
    if (newSelection.has(imageId)) {
      newSelection.delete(imageId);
    } else {
      newSelection.add(imageId);
    }
    setSelectedCardsToAdd(newSelection);
  };

  // Export deck as PDF
  const exportDeckAsPDF = async () => {
    if (!selectedDeck || !deckCardsQuery.data?.length) {
      toast.error("No cards to export");
      return;
    }

    setIsExporting(true);
    try {
      const cards = deckCardsQuery.data;
      const pdf = new jsPDF({
        orientation: "portrait",
        unit: "mm",
        format: "a4",
      });

      if (exportFormat === "pdf-single") {
        // One card per page
        for (let i = 0; i < cards.length; i++) {
          if (i > 0) pdf.addPage();
          
          const card = cards[i];
          const img = new Image();
          img.crossOrigin = "anonymous";
          
              await new Promise<void>((resolve, reject) => {
            img.onload = () => {
              // Center card on page (A4: 210x297mm)
              const cardWidth = 63.5; // Standard trading card width in mm
              const cardHeight = 88.9; // Standard trading card height in mm
              const x = (210 - cardWidth) / 2;
              const y = (297 - cardHeight) / 2;
              
              pdf.addImage(img, "JPEG", x, y, cardWidth, cardHeight);
              
              // Add card number
              pdf.setFontSize(10);
              pdf.setTextColor(128, 128, 128);
              pdf.text(`Card ${i + 1} of ${cards.length}`, 105, 290, { align: "center" });
              
              resolve();
            };
            img.onerror = reject;
            img.src = card.image.imageUrl || '';
          });
        }
      } else {
        // Grid layout (3x3 per page)
        const cardsPerPage = 9;
        const cardWidth = 60;
        const cardHeight = 84;
        const marginX = 15;
        const marginY = 15;
        const gapX = 5;
        const gapY = 5;

        for (let pageIndex = 0; pageIndex < Math.ceil(cards.length / cardsPerPage); pageIndex++) {
          if (pageIndex > 0) pdf.addPage();
          
          const pageCards = cards.slice(pageIndex * cardsPerPage, (pageIndex + 1) * cardsPerPage);
          
          for (let i = 0; i < pageCards.length; i++) {
            const card = pageCards[i];
            const col = i % 3;
            const row = Math.floor(i / 3);
            const x = marginX + col * (cardWidth + gapX);
            const y = marginY + row * (cardHeight + gapY);
            
            const img = new Image();
            img.crossOrigin = "anonymous";
            
            await new Promise<void>((resolve, reject) => {
              img.onload = () => {
                pdf.addImage(img, "JPEG", x, y, cardWidth, cardHeight);
                resolve();
              };
              img.onerror = reject;
                img.src = card.image.imageUrl || '';
            });
          }
          
          // Add page number
          pdf.setFontSize(10);
          pdf.setTextColor(128, 128, 128);
          pdf.text(
            `Page ${pageIndex + 1} of ${Math.ceil(cards.length / cardsPerPage)}`,
            105, 290, { align: "center" }
          );
        }
      }

      pdf.save(`${selectedDeck.name.replace(/\s+/g, "-")}-deck.pdf`);
      toast.success("Deck exported as PDF!");
    } catch (error) {
      console.error("Export error:", error);
      toast.error("Failed to export deck");
    } finally {
      setIsExporting(false);
    }
  };

  if (authLoading) {
    return (
      <AppLayout>
        <div className="flex items-center justify-center h-[50vh]">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      </AppLayout>
    );
  }

  if (!isAuthenticated) {
    return (
      <AppLayout>
        <div className="flex flex-col items-center justify-center h-[50vh] gap-4">
          <Layers className="w-16 h-16 text-muted-foreground" />
          <h2 className="text-2xl font-bold">Sign in to build decks</h2>
          <p className="text-muted-foreground">
            Create custom card decks and export them for printing.
          </p>
          <Button asChild>
            <a href={getLoginUrl()}>Sign In</a>
          </Button>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="container py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold flex items-center gap-2">
              <Layers className="w-8 h-8 text-primary" />
              Deck Builder
            </h1>
            <p className="text-muted-foreground mt-1">
              Build custom card decks and export them for printing
            </p>
          </div>
          <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="w-4 h-4 mr-2" />
                New Deck
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create New Deck</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Deck Name</Label>
                  <Input
                    id="name"
                    placeholder="e.g., My Championship Deck"
                    value={newDeckName}
                    onChange={(e) => setNewDeckName(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="description">Description (optional)</Label>
                  <Textarea
                    id="description"
                    placeholder="Describe your deck..."
                    value={newDeckDescription}
                    onChange={(e) => setNewDeckDescription(e.target.value)}
                  />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setCreateDialogOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleCreate} disabled={createDeck.isPending}>
                  {createDeck.isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                  Create Deck
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Decks List */}
          <div className="lg:col-span-1">
            <h2 className="text-lg font-semibold mb-4">Your Decks</h2>
            {decksQuery.isLoading ? (
              <div className="flex items-center justify-center h-40">
                <Loader2 className="w-6 h-6 animate-spin text-primary" />
              </div>
            ) : decksQuery.data?.length === 0 ? (
              <Card className="border-dashed">
                <CardContent className="flex flex-col items-center justify-center py-8">
                  <Layers className="w-12 h-12 text-muted-foreground mb-2" />
                  <p className="text-sm text-muted-foreground">No decks yet</p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-2">
                {decksQuery.data?.map((deck) => (
                  <Card
                    key={deck.id}
                    className={cn(
                      "cursor-pointer transition-all",
                      selectedDeck?.id === deck.id
                        ? "border-primary ring-2 ring-primary/20"
                        : "hover:border-primary/50"
                    )}
                    onClick={() => setSelectedDeck(deck)}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="font-medium">{deck.name}</h3>
                          <p className="text-sm text-muted-foreground">
                            {deck.cardCount} cards
                          </p>
                        </div>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                            <Button variant="ghost" size="icon">
                              <MoreVertical className="w-4 h-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={(e) => {
                              e.stopPropagation();
                              openEditDialog(deck);
                            }}>
                              <Edit className="w-4 h-4 mr-2" />
                              Edit
                            </DropdownMenuItem>
                            <DropdownMenuItem
                              className="text-destructive"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleDelete(deck.id);
                              }}
                            >
                              <Trash2 className="w-4 h-4 mr-2" />
                              Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>

          {/* Deck Contents */}
          <div className="lg:col-span-2">
            {selectedDeck ? (
              <div>
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h2 className="text-lg font-semibold">{selectedDeck.name}</h2>
                    {selectedDeck.description && (
                      <p className="text-sm text-muted-foreground">{selectedDeck.description}</p>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    <Button variant="outline" onClick={() => setAddCardsDialogOpen(true)}>
                      <Plus className="w-4 h-4 mr-2" />
                      Add Cards
                    </Button>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button disabled={!deckCardsQuery.data?.length || isExporting}>
                          {isExporting ? (
                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          ) : (
                            <Download className="w-4 h-4 mr-2" />
                          )}
                          Export PDF
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => {
                          setExportFormat("pdf-single");
                          exportDeckAsPDF();
                        }}>
                          <FileText className="w-4 h-4 mr-2" />
                          One Card Per Page
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => {
                          setExportFormat("pdf-grid");
                          exportDeckAsPDF();
                        }}>
                          <Grid3X3 className="w-4 h-4 mr-2" />
                          Grid Layout (3x3)
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </div>

                {deckCardsQuery.isLoading ? (
                  <div className="flex items-center justify-center h-40">
                    <Loader2 className="w-6 h-6 animate-spin text-primary" />
                  </div>
                ) : deckCardsQuery.data?.length === 0 ? (
                  <Card className="border-dashed">
                    <CardContent className="flex flex-col items-center justify-center py-16">
                      <Images className="w-12 h-12 text-muted-foreground mb-2" />
                      <p className="text-muted-foreground mb-4">No cards in this deck yet</p>
                      <Button variant="outline" onClick={() => setAddCardsDialogOpen(true)}>
                        <Plus className="w-4 h-4 mr-2" />
                        Add Cards
                      </Button>
                    </CardContent>
                  </Card>
                ) : (
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                    <AnimatePresence>
                      {deckCardsQuery.data?.map((card, index) => (
                        <motion.div
                          key={card.id}
                          initial={{ opacity: 0, scale: 0.9 }}
                          animate={{ opacity: 1, scale: 1 }}
                          exit={{ opacity: 0, scale: 0.9 }}
                          className="group relative"
                        >
                          <Card className="overflow-hidden">
                            <div className="aspect-[2/3] relative">
                              <img
                                src={card.image.imageUrl || ''}
                                alt={`Card ${index + 1}`}
                                className="w-full h-full object-cover"
                              />
                              <div className="absolute top-2 left-2 bg-black/60 text-white text-xs px-2 py-1 rounded">
                                #{index + 1}
                              </div>
                              <Button
                                variant="destructive"
                                size="icon"
                                className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity w-7 h-7"
                                onClick={() => handleRemoveCard(card.imageId)}
                              >
                                <X className="w-4 h-4" />
                              </Button>
                            </div>
                          </Card>
                        </motion.div>
                      ))}
                    </AnimatePresence>
                  </div>
                )}
              </div>
            ) : (
              <Card className="border-dashed h-full min-h-[400px]">
                <CardContent className="flex flex-col items-center justify-center h-full">
                  <Layers className="w-16 h-16 text-muted-foreground mb-4" />
                  <h3 className="text-xl font-semibold mb-2">Select a Deck</h3>
                  <p className="text-muted-foreground text-center">
                    Choose a deck from the list or create a new one to start building.
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>

        {/* Add Cards Dialog */}
        <Dialog open={addCardsDialogOpen} onOpenChange={setAddCardsDialogOpen}>
          <DialogContent className="max-w-4xl max-h-[80vh]">
            <DialogHeader>
              <DialogTitle>Add Cards to {selectedDeck?.name}</DialogTitle>
            </DialogHeader>
            <ScrollArea className="h-[50vh]">
              {galleryQuery.isLoading ? (
                <div className="flex items-center justify-center h-40">
                  <Loader2 className="w-6 h-6 animate-spin text-primary" />
                </div>
              ) : (
                <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-3 p-1">
                  {galleryQuery.data?.map((image: { id: number; imageUrl: string | null; prompt: string }) => (
                    <button
                      key={image.id}
                      onClick={() => toggleCardSelection(image.id)}
                      className={cn(
                        "aspect-[2/3] rounded-lg overflow-hidden border-2 transition-all",
                        selectedCardsToAdd.has(image.id)
                          ? "border-primary ring-2 ring-primary/20"
                          : "border-transparent hover:border-primary/50"
                      )}
                    >
                      <img
                        src={image.imageUrl || ''}
                        alt={image.prompt}
                        className="w-full h-full object-cover"
                      />
                    </button>
                  ))}
                </div>
              )}
            </ScrollArea>
            <DialogFooter>
              <div className="flex items-center justify-between w-full">
                <span className="text-sm text-muted-foreground">
                  {selectedCardsToAdd.size} cards selected
                </span>
                <div className="flex gap-2">
                  <Button variant="outline" onClick={() => setAddCardsDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button
                    onClick={handleAddCards}
                    disabled={selectedCardsToAdd.size === 0 || addCardsToDeck.isPending}
                  >
                    {addCardsToDeck.isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                    Add {selectedCardsToAdd.size} Cards
                  </Button>
                </div>
              </div>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Edit Dialog */}
        <Dialog open={!!editingDeck} onOpenChange={(open) => !open && setEditingDeck(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Edit Deck</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="edit-name">Deck Name</Label>
                <Input
                  id="edit-name"
                  value={newDeckName}
                  onChange={(e) => setNewDeckName(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-description">Description</Label>
                <Textarea
                  id="edit-description"
                  value={newDeckDescription}
                  onChange={(e) => setNewDeckDescription(e.target.value)}
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setEditingDeck(null)}>
                Cancel
              </Button>
              <Button onClick={handleUpdate} disabled={updateDeckMutation.isPending}>
                {updateDeckMutation.isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                Save Changes
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </AppLayout>
  );
}
