import { useAuth } from "@/_core/hooks/useAuth";
import { AppLayout } from "@/components/AppLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import { cn } from "@/lib/utils";
import { motion, AnimatePresence } from "framer-motion";
import {
  Plus,
  FolderOpen,
  Images,
  Loader2,
  Trash2,
  Edit,
  MoreVertical,
  Sparkles,
  Calendar,
  Hash,
} from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { Link } from "wouter";
import { getLoginUrl } from "@/const";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface Collection {
  id: number;
  name: string;
  description: string | null;
  theme: string | null;
  borderStyle: string | null;
  cardCount: number;
  createdAt: Date;
}

export default function Collections() {
  const { isAuthenticated, loading: authLoading } = useAuth();
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [editingCollection, setEditingCollection] = useState<Collection | null>(null);
  const [newCollectionName, setNewCollectionName] = useState("");
  const [newCollectionDescription, setNewCollectionDescription] = useState("");
  const [newCollectionTheme, setNewCollectionTheme] = useState("");

  const utils = trpc.useUtils();

  // Queries
  const collectionsQuery = trpc.collections.list.useQuery(
    undefined,
    { enabled: isAuthenticated }
  );

  // Mutations
  const createCollection = trpc.collections.create.useMutation({
    onSuccess: () => {
      toast.success("Collection created!");
      utils.collections.list.invalidate();
      setCreateDialogOpen(false);
      resetForm();
    },
    onError: (error) => {
      toast.error(error.message || "Failed to create collection");
    },
  });

  const updateCollection = trpc.collections.update.useMutation({
    onSuccess: () => {
      toast.success("Collection updated!");
      utils.collections.list.invalidate();
      setEditingCollection(null);
      resetForm();
    },
    onError: (error) => {
      toast.error(error.message || "Failed to update collection");
    },
  });

  const deleteCollection = trpc.collections.delete.useMutation({
    onSuccess: () => {
      toast.success("Collection deleted!");
      utils.collections.list.invalidate();
    },
    onError: (error) => {
      toast.error(error.message || "Failed to delete collection");
    },
  });

  const resetForm = () => {
    setNewCollectionName("");
    setNewCollectionDescription("");
    setNewCollectionTheme("");
  };

  const handleCreate = () => {
    if (!newCollectionName.trim()) {
      toast.error("Please enter a collection name");
      return;
    }
    createCollection.mutate({
      name: newCollectionName.trim(),
      description: newCollectionDescription.trim() || undefined,
      theme: newCollectionTheme.trim() || undefined,
    });
  };

  const handleUpdate = () => {
    if (!editingCollection || !newCollectionName.trim()) {
      toast.error("Please enter a collection name");
      return;
    }
    updateCollection.mutate({
      id: editingCollection.id,
      name: newCollectionName.trim(),
      description: newCollectionDescription.trim() || undefined,
      theme: newCollectionTheme.trim() || undefined,
    });
  };

  const handleDelete = (id: number) => {
    if (confirm("Are you sure you want to delete this collection? Cards in this collection will not be deleted.")) {
      deleteCollection.mutate({ id });
    }
  };

  const openEditDialog = (collection: Collection) => {
    setEditingCollection(collection);
    setNewCollectionName(collection.name);
    setNewCollectionDescription(collection.description || "");
    setNewCollectionTheme(collection.theme || "");
  };

  // Theme colors for collections
  const themeColors: Record<string, string> = {
    sports: "from-orange-500 to-red-500",
    fantasy: "from-purple-500 to-pink-500",
    scifi: "from-cyan-500 to-blue-500",
    anime: "from-pink-500 to-rose-500",
    classic: "from-amber-500 to-yellow-500",
    default: "from-indigo-500 to-purple-500",
  };

  if (authLoading) {
    return (
      <AppLayout>
        <div className="flex items-center justify-center h-[50vh]">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      </AppLayout>
    );
  }

  if (!isAuthenticated) {
    return (
      <AppLayout>
        <div className="flex flex-col items-center justify-center h-[50vh] gap-4">
          <FolderOpen className="w-16 h-16 text-muted-foreground" />
          <h2 className="text-2xl font-bold">Sign in to view your collections</h2>
          <p className="text-muted-foreground">
            Create themed card collections and organize your generated cards.
          </p>
          <Button asChild>
            <a href={getLoginUrl()}>Sign In</a>
          </Button>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="container py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold flex items-center gap-2">
              <FolderOpen className="w-8 h-8 text-primary" />
              My Collections
            </h1>
            <p className="text-muted-foreground mt-1">
              Organize your cards into themed collections
            </p>
          </div>
          <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="w-4 h-4 mr-2" />
                New Collection
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create New Collection</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Collection Name</Label>
                  <Input
                    id="name"
                    placeholder="e.g., NBA Legends, Fantasy Warriors"
                    value={newCollectionName}
                    onChange={(e) => setNewCollectionName(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="description">Description (optional)</Label>
                  <Textarea
                    id="description"
                    placeholder="Describe your collection..."
                    value={newCollectionDescription}
                    onChange={(e) => setNewCollectionDescription(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="theme">Theme (optional)</Label>
                  <Input
                    id="theme"
                    placeholder="e.g., sports, fantasy, scifi, anime"
                    value={newCollectionTheme}
                    onChange={(e) => setNewCollectionTheme(e.target.value)}
                  />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setCreateDialogOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleCreate} disabled={createCollection.isPending}>
                  {createCollection.isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                  Create Collection
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>

        {/* Collections Grid */}
        {collectionsQuery.isLoading ? (
          <div className="flex items-center justify-center h-[40vh]">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : collectionsQuery.data?.length === 0 ? (
          <Card className="border-dashed">
            <CardContent className="flex flex-col items-center justify-center py-16">
              <FolderOpen className="w-16 h-16 text-muted-foreground mb-4" />
              <h3 className="text-xl font-semibold mb-2">No collections yet</h3>
              <p className="text-muted-foreground text-center mb-4">
                Create your first collection to start organizing your cards.
              </p>
              <Button onClick={() => setCreateDialogOpen(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Create Collection
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <AnimatePresence>
              {collectionsQuery.data?.map((collection, index) => (
                <motion.div
                  key={collection.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  transition={{ delay: index * 0.05 }}
                >
                  <Card className="group hover:shadow-lg transition-all duration-300 overflow-hidden">
                    {/* Gradient Header */}
                    <div className={cn(
                      "h-24 bg-gradient-to-r relative",
                      themeColors[collection.theme || "default"] || themeColors.default
                    )}>
                      <div className="absolute inset-0 bg-black/20" />
                      <div className="absolute top-2 right-2">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="text-white hover:bg-white/20">
                              <MoreVertical className="w-4 h-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => openEditDialog(collection)}>
                              <Edit className="w-4 h-4 mr-2" />
                              Edit
                            </DropdownMenuItem>
                            <DropdownMenuItem 
                              className="text-destructive"
                              onClick={() => handleDelete(collection.id)}
                            >
                              <Trash2 className="w-4 h-4 mr-2" />
                              Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                      <div className="absolute bottom-4 left-4">
                        <h3 className="text-xl font-bold text-white drop-shadow-lg">
                          {collection.name}
                        </h3>
                      </div>
                    </div>
                    
                    <CardContent className="pt-4">
                      {collection.description && (
                        <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                          {collection.description}
                        </p>
                      )}
                      
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4 text-sm text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <Images className="w-4 h-4" />
                            {collection.cardCount} cards
                          </span>
                          <span className="flex items-center gap-1">
                            <Calendar className="w-4 h-4" />
                            {new Date(collection.createdAt).toLocaleDateString()}
                          </span>
                        </div>
                        {collection.theme && (
                          <Badge variant="secondary" className="text-xs">
                            {collection.theme}
                          </Badge>
                        )}
                      </div>
                      
                      <Button 
                        variant="outline" 
                        className="w-full mt-4"
                        asChild
                      >
                        <Link href={`/collections/${collection.id}`}>
                          View Collection
                        </Link>
                      </Button>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        )}

        {/* Edit Dialog */}
        <Dialog open={!!editingCollection} onOpenChange={(open) => !open && setEditingCollection(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Edit Collection</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="edit-name">Collection Name</Label>
                <Input
                  id="edit-name"
                  value={newCollectionName}
                  onChange={(e) => setNewCollectionName(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-description">Description</Label>
                <Textarea
                  id="edit-description"
                  value={newCollectionDescription}
                  onChange={(e) => setNewCollectionDescription(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-theme">Theme</Label>
                <Input
                  id="edit-theme"
                  value={newCollectionTheme}
                  onChange={(e) => setNewCollectionTheme(e.target.value)}
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setEditingCollection(null)}>
                Cancel
              </Button>
              <Button onClick={handleUpdate} disabled={updateCollection.isPending}>
                {updateCollection.isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                Save Changes
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </AppLayout>
  );
}
