# Grok Imagine & OpenAI 4o API Research

## Grok Imagine API (Text-to-Image)

**Endpoint:** POST /api/v1/jobs/createTask
**Model:** grok-imagine/text-to-image
**Pricing:** 4 credits ($0.02) per generation - get 6 images each time

### Request Parameters:
- `model` (Required, string): "grok-imagine/text-to-image"
- `callBackUrl` (Optional, string): Callback URL for task completion notifications
- `input.prompt` (Required, string): Max 5000 characters
- `input.aspect_ratio` (Optional, string): Available options: 2:3, 3:2, 1:1, 9:16, 16:9

### Authentication:
- Bearer Token: Authorization: Bearer YOUR_API_KEY

### Notes:
- Returns 6 images per generation
- Same task polling endpoint as Nano Banana

---

## OpenAI 4o Image API (GPT-Image-1)

**Endpoint:** POST /api/v1/gpt4o-image/generate
**Model:** GPT-Image-1 (ChatGPT 4o Image)
**Pricing:** 6 credits (~$0.03) per image

### Request Parameters:
- `size` (Required, string): Aspect ratio - "1:1", "3:2", "2:3"
- `prompt` (Optional, string): Text prompt for generation. Required if no filesUrl provided.
- `filesUrl` (Optional, array of strings): URLs of images to edit/transform

### Authentication:
- Bearer Token: Authorization: Bearer YOUR_API_KEY

### Response:
```json
{
  "code": 200,
  "msg": "success",
  "data": {
    "taskId": "task12345"
  }
}
```

### Get Task Details:
- GET endpoint to retrieve generated images

### Notes:
- Images stored for 14 days
- Supports both text-to-image and image editing
- Renders legible text in images

