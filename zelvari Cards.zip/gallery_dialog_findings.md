# Gallery Dialog Findings

## Issue
The dialog opens and shows the image correctly, but:
1. The action buttons (Download, Edit & Crop, Add Watermark, Recreate, Delete, Close) are visible but the dialog layout needs improvement
2. The dialog scrolls the whole page instead of just the content
3. The buttons are at the bottom but may be cut off on smaller screens

## Solution Needed
1. Make the dialog content scrollable within the dialog, not the whole page
2. Keep action buttons always visible at the bottom
3. Ensure the image and details panel have proper max heights
