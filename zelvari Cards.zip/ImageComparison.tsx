      {comparisonImages.slice(0, 4).map((img, index) => (
        <motion.div
          key={img.id}
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: index * 0.1 }}
          className="relative rounded-lg overflow-hidden bg-muted"
        >
          <img
            src={img.imageUrl}
            alt={`Comparison ${index + 1}`}
            className="w-full h-full object-contain"
          />
          <div className="absolute top-2 left-2">
            {renderModelBadge(img.model)}
          </div>
          <Button
            size="sm"
            variant="secondary"
            className="absolute bottom-2 right-2"
            onClick={() => handleDownload(img.imageUrl, img.model)}
          >
            <Download className="w-4 h-4" />
          </Button>
        </motion.div>
      ))}
    </div>
  );

  const renderSlider = () => {
    if (comparisonImages.length < 2) {
      return (
        <div className="h-[60vh] flex items-center justify-center text-muted-foreground">
          Select at least 2 images to use slider comparison
        </div>
      );
    }

    const leftImage = comparisonImages[0];
    const rightImage = comparisonImages[1];

    return (
      <div className="relative h-[60vh] rounded-lg overflow-hidden bg-muted">
        {/* Right image (full) */}
        <img
          src={rightImage.imageUrl}
          alt="Right comparison"
          className="absolute inset-0 w-full h-full object-contain"
        />
        
        {/* Left image (clipped) */}
        <div
          className="absolute inset-0 overflow-hidden"
          style={{ width: `${sliderPosition}%` }}
        >
          <img
            src={leftImage.imageUrl}
            alt="Left comparison"
            className="absolute inset-0 w-full h-full object-contain"
            style={{ width: `${100 / (sliderPosition / 100)}%`, maxWidth: "none" }}
          />
        </div>

        {/* Slider line */}
        <div
          className="absolute top-0 bottom-0 w-1 bg-white shadow-lg cursor-ew-resize z-10"
          style={{ left: `${sliderPosition}%`, transform: "translateX(-50%)" }}
        >
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-8 h-8 bg-white rounded-full shadow-lg flex items-center justify-center">
            <ChevronLeft className="w-3 h-3 text-gray-600" />
            <ChevronRight className="w-3 h-3 text-gray-600" />
          </div>
        </div>

        {/* Model badges */}
        <div className="absolute top-2 left-2">
          {renderModelBadge(leftImage.model)}
        </div>
        <div className="absolute top-2 right-2">
          {renderModelBadge(rightImage.model)}
        </div>

        {/* Slider control */}
        <div className="absolute bottom-4 left-4 right-4">
          <Slider
            value={[sliderPosition]}
            onValueChange={([v]) => setSliderPosition(v)}
            min={5}
            max={95}
            step={1}
            className="w-full"
          />
        </div>
      </div>
    );
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl max-h-[95vh] overflow-hidden bg-background text-foreground">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle className="flex items-center gap-2">
              <Columns className="w-5 h-5 text-primary" />
              Compare AI Models
            </DialogTitle>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="w-4 h-4" />
            </Button>
          </div>
        </DialogHeader>

        <div className="space-y-4">
          {/* View Mode Selector */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Label className="text-sm">View Mode:</Label>
              <div className="flex gap-1">
                <Button
                  variant={viewMode === "side-by-side" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setViewMode("side-by-side")}
                >
                  <Columns className="w-4 h-4" />
                </Button>
                <Button
                  variant={viewMode === "stacked" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setViewMode("stacked")}
                >
                  <Rows className="w-4 h-4" />
                </Button>
                <Button
                  variant={viewMode === "grid" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setViewMode("grid")}
                >
                  <Grid2X2 className="w-4 h-4" />
                </Button>
                <Button
                  variant={viewMode === "slider" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setViewMode("slider")}
                >
                  <SplitSquareHorizontal className="w-4 h-4" />
                </Button>
              </div>
            </div>

            <div className="text-sm text-muted-foreground">