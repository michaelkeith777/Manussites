---
name: vault-gate-builder
description: Build interactive vault/combination lock gate pages that protect web applications behind a passcode entry screen. Use when creating password-protected landing pages, vault door animations, combination dial interfaces, secure entry gates, or any app that needs an immersive lock/unlock experience before granting access.
---

# Vault Gate Builder

Build a full-screen vault combination lock that gates access to a web application. The vault features a rotating combination dial, mechanical sound effects via Web Audio API, 3D perspective door opening animation, confetti/sparkle celebration, hinge dust particles, and floating gear background.

## Dependencies

Requires React 18+, Framer Motion, and Tailwind CSS:

```bash
pnpm add framer-motion
```

## Quick Start

1. Copy `templates/VaultLock.tsx` into the project's components directory
2. Set the `PASSCODE` constant at line 4 to the desired combination (digits only)
3. Wrap the app with the vault gate in the root component:

```tsx
import { VaultLock } from "./components/VaultLock";

function App() {
  const [unlocked, setUnlocked] = useState(
    () => sessionStorage.getItem("vault_unlocked") === "true"
  );

  const handleUnlock = useCallback(() => {
    sessionStorage.setItem("vault_unlocked", "true");
    setUnlocked(true);
  }, []);

  if (!unlocked) return <VaultLock onUnlock={handleUnlock} />;
  return <MainApp />;
}
```

## Component Architecture

The template contains these sub-components (all in one file):

| Component | Purpose |
|-----------|---------|
| `VaultSounds` | Web Audio API class — click, dial turn, unlock, celebrate, error sounds |
| `GearSVG` | Parametric SVG gear with configurable teeth/radii |
| `FloatingGears` | 10 animated background gears with rotation + bobbing |
| `ModernDial` | SVG combination dial with 40 segments, gradient accents, concentric hub |
| `DigitDisplay` | Row of digit slots showing entered code progress |
| `NumberPad` | 3x4 grid (1-9, C, 0, Enter) with hover/press feedback |
| `CelebrationEffect` | 80 confetti pieces + 40 sparkle stars + central burst |
| `HingeDust` | Dust particles from 6 hinge positions + center seam burst |
| `VaultLock` | Main orchestrator — state machine: locked, unlocking, opening, welcome |

## Unlock Sequence

```
User enters digits -> dial rotates alternating CW/CCW -> all digits entered
  -> [300ms] unlocking phase: dial spins 720deg, dial turn sound
  -> [1800ms] opening phase: 3D doors swing open (rotateY +/-105deg), unlock sound,
     celebration confetti + sparkles + chime, hinge dust particles
  -> [3800ms] welcome phase: "Welcome" text + progress bar + continued celebration
  -> [6000ms] onUnlock() callback fires -> app loads
```

Wrong code: shake animation + error buzz, auto-clear after 1200ms.

## Customization

For detailed customization of colors, sounds, timing, door style, celebration effects, dust particles, floating gears, welcome screen, and session persistence, see `references/customization.md`.

### Common Customizations

**Change passcode:** Edit `const PASSCODE = "02141971"` at line 4.

**Change theme color:** Search-replace `purple` and `139,92,246` with your accent color RGB values.

**Change title:** Edit the h1 text `"Welcome to the Creation Vault"` in the locked phase JSX (around line 947).

**Change welcome text:** Edit the welcome phase JSX (around line 875).

**Disable sounds:** Empty the method bodies in `VaultSounds` class.

**Adjust total duration:** Modify the setTimeout values in `handleDigitPress` (lines 783-801).

## Layout Notes

- Uses `100dvh` height with `overflow-hidden` to prevent scrolling
- All elements use `clamp()` for responsive sizing across viewports
- Dial size: `clamp(140px, 25vh, 208px)`
- Title: `clamp(1.2rem, 3.5vh, 2.25rem)`
- Number pad buttons: `clamp(36px, 5.5vh, 52px)` height
- Fixed z-index layering: vault 9999, doors 10000, dust 10002

## Keyboard Support

Built-in keyboard handler via useEffect:
- Number keys 0-9: enter digits
- Backspace/Delete/Escape: clear all entered digits
- Uses useRef pattern to avoid stale closures in the event listener
