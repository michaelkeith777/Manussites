# Kie.ai API Research

## API Overview
- Base URL: `https://api.kie.ai/api/v1/jobs/createTask`
- Authentication: Bearer Token (API Key)
- All tasks are asynchronous - returns taskId immediately
- Use callback URL or poll for results

## Nano Banana Pro API

### Endpoint
POST `https://api.kie.ai/api/v1/jobs/createTask`

### Headers
- Authorization: Bearer <API_KEY>
- Content-Type: application/json

### Request Body
```json
{
  "model": "nano-banana-pro",
  "callBackUrl": "https://your-domain.com/api/callback",
  "input": {
    "prompt": "Text description of image to generate",
    "image_input": [],  // Optional - reference images
    "aspect_ratio": "1:1",  // Options: 1:1, 2:3, 3:2, 3:4, 4:3, 4:5, 5:4, 9:16, 16:9, 21:9, auto
    "resolution": "1K",  // Options: 1K, 2K, 4K
    "output_format": "png"  // Options: png, jpg
  }
}
```

### Response
```json
{
  "code": 200,
  "msg": "success",
  "data": {
    "taskId": "task_nano-banana-pro_1765178625768"
  }
}
```

### Status Codes
- 200: Success
- 401: Unauthorized
- 402: Insufficient Credits
- 404: Not Found
- 422: Validation Error
- 429: Rate Limited
- 455: Service Unavailable
- 500: Server Error
- 501: Generation Failed
- 505: Feature Disabled

## Nano Banana (Standard) API
- Model name: "nano-banana"
- Similar parameters to Pro version
- Lower cost option

## Get Task Details
- Endpoint: GET to query task status
- Use taskId to retrieve results
- Results include generated image URLs

## Pricing
- ~$0.02 per image for Nano Banana
- Credit-based system
- 30-50% lower than official APIs

## Data Retention
- Generated media: 14 days
- Log records: 2 months

## Rate Limits
- 20 new requests per 10 seconds
- ~100+ concurrent tasks allowed


## Get Task Details API

### Endpoint
GET `https://api.kie.ai/api/v1/jobs/recordInfo?taskId={taskId}`

### Response
```json
{
  "code": 200,
  "message": "success",
  "data": {
    "taskId": "task_12345678",
    "model": "grok-imagine/text-to-image",
    "state": "success",
    "param": "{...original request params...}",
    "resultJson": "{\"resultUrls\":[\"https://example.com/generated-content.jpg\"]}",
    "failCode": "",
    "failMsg": "",
    "completeTime": 1698765432000,
    "createTime": 1698765400000,
    "updateTime": 1698765432000
  }
}
```

### Task States
- waiting
- queuing
- generating
- success
- fail

### Polling Best Practices
- Initial polls (first 30s): Every 2-3 seconds
- After 30 seconds: Every 5-10 seconds
- After 2 minutes: Every 15-30 seconds
- Maximum: Stop after 10-15 minutes

### Important Notes
- Generated content URLs expire after 24 hours
- Use callBackUrl for production (no polling needed)
- Rate limit: 10 requests per second per API key
