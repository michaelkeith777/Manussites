# Vault Gate Customization Guide

## Table of Contents
- Passcode Configuration
- Theme Colors
- Sound Effects
- Animation Timing
- Door Style
- Celebration Effects
- Dust Particles
- Floating Gears
- Welcome Screen
- Session Persistence

## Passcode Configuration

Change the `PASSCODE` constant at the top of VaultLock.tsx:

```tsx
const PASSCODE = "12345678"; // Must be digits only, any length
```

The digit display auto-adjusts to the passcode length. For shorter codes (4-6 digits), reduce the number pad layout or keep it as-is.

## Theme Colors

The vault uses a purple/indigo palette by default. Key color locations:

| Element | Property | Default |
|---------|----------|---------|
| Background | radial-gradient | `#1a1030` → `#0a0a15` |
| Dial glow | rgba | `rgba(139,92,246,...)` |
| Text gradient | linear-gradient | `#c4b5fd, #a78bfa, #818cf8` |
| Bolt indicators | background | `rgba(139,92,246,0.8)` |
| Number pad hover | background | `rgba(139,92,246,0.15)` |
| Floating gears | className | `text-purple-400` |

To change theme: search-replace `purple` and `139,92,246` with your accent color.

## Sound Effects

The `VaultSounds` class uses Web Audio API (no external files). Methods:

- `click()` — Button press feedback (short square wave)
- `dialTurn(duration)` — Mechanical clicking during dial rotation
- `unlock()` — Heavy bolt + scrape + hinge creak sequence
- `celebrate()` — Ascending chime + shimmer
- `error()` — Low buzz for wrong code

To disable sounds: replace method bodies with empty blocks.
To customize: adjust frequency values, oscillator types, and gain envelopes.

## Animation Timing

The unlock sequence phases and their durations:

```
locked → [300ms check] → unlocking (1800ms) → opening (2000ms) → welcome (2200ms) → onUnlock()
```

Key timeouts in `handleDigitPress`:
- `setTimeout(() => setPhase("unlocking"), 300)` — Post-entry delay
- `setTimeout(() => setPhase("opening"), 1800)` — Dial spin duration
- `setTimeout(() => setPhase("welcome"), 3800)` — Door open duration
- `setTimeout(() => onUnlock(), 6000)` — Total sequence before app loads

## Door Style

The 3D doors use CSS `perspective: 1200px` and `rotateY` transforms:
- Left door: `rotateY(-105deg)`, origin `left center`
- Right door: `rotateY(105deg)`, origin `right center`

Door details include:
- Metallic gradient background
- Brushed texture overlay (repeating-linear-gradient)
- Rivet positions at 10%, 25%, 40%, 55%, 70%, 85% vertical
- Hinge details at 20%, 50%, 80% vertical
- Center seam with shadow
- Number plates ("L-01", "R-01")

## Celebration Effects

`CelebrationEffect` component renders confetti + sparkles using Framer Motion:
- 80 confetti pieces with random colors, sizes, rotation, gravity
- 40 sparkle stars with pulse and fade
- Central burst flash

Colors array: `['#a78bfa', '#818cf8', '#c4b5fd', '#f472b6', '#fb923c', '#34d399', '#fbbf24', '#60a5fa']`

## Dust Particles

`HingeDust` component spawns particles from 6 hinge positions:
- 12-18 particles per hinge with earthy brown/tan colors
- 30 center seam dust particles
- Dust cloud puffs at each hinge with radial gradient blur

## Floating Gears

`FloatingGears` renders 10 SVG gears with:
- Varying tooth counts (6-16), sizes (55-150px)
- Alternating rotation directions
- Gentle vertical bobbing animation
- Low opacity (0.04-0.08) for subtlety

## Welcome Screen

After doors open, shows:
- "Welcome" heading with gradient text
- "Entering the Creation Vault..." subtitle
- Animated progress bar
- Continued celebration effects

Customize the welcome text in the `phase === "welcome"` JSX block.

## Session Persistence

The parent component should manage persistence. Recommended pattern:

```tsx
const [vaultUnlocked, setVaultUnlocked] = useState(
  () => sessionStorage.getItem("vault_unlocked") === "true"
);

const handleUnlock = useCallback(() => {
  sessionStorage.setItem("vault_unlocked", "true");
  setVaultUnlocked(true);
}, []);

if (!vaultUnlocked) return <VaultLock onUnlock={handleUnlock} />;
```

Options:
- `sessionStorage` — Resets on tab close (recommended for security)
- `localStorage` — Persists across sessions
- Server-side — Store unlock state in database per user
