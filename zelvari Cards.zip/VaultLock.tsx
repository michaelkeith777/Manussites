                    </div>
                  </div>
                </motion.div>

                {/* Right door - hinges from right edge */}
                <motion.div
                  initial={{ rotateY: 0 }}
                  animate={{ rotateY: 105 }}
                  transition={{ delay: 0.6, duration: 2.2, ease: [0.25, 0.1, 0.25, 1] }}
                  className="absolute top-0 right-0 w-1/2 h-full"
                  style={{
                    transformOrigin: 'right center',
                    transformStyle: 'preserve-3d',
                    backfaceVisibility: 'hidden',
                  }}
                >
                  {/* Door front face */}
                  <div className="absolute inset-0" style={{
                    background: 'linear-gradient(-135deg, #1a1a2e 0%, #16162a 30%, #1e1e38 60%, #141428 100%)',
                    boxShadow: 'inset 2px 0 8px rgba(139,92,246,0.1), -4px 0 30px rgba(0,0,0,0.8)',
                  }}>
                    {/* Metallic brushed texture */}
                    <div className="absolute inset-0 opacity-[0.04]" style={{
                      backgroundImage: 'repeating-linear-gradient(90deg, transparent, transparent 2px, rgba(255,255,255,0.03) 2px, rgba(255,255,255,0.03) 3px)',
                    }} />
                    {/* Rivets */}
                    {[10, 25, 40, 55, 70, 85].map((y) => (
                      <div key={`rl-${y}`} className="absolute" style={{ left: '12px', top: `${y}%` }}>
                        <div className="w-3 h-3 rounded-full" style={{
                          background: 'radial-gradient(circle at 35% 35%, #3a3a5c, #1a1a2e)',
                          boxShadow: 'inset 0 1px 2px rgba(255,255,255,0.1), 0 1px 3px rgba(0,0,0,0.5)',
                        }} />
                      </div>
                    ))}
                    {[10, 25, 40, 55, 70, 85].map((y) => (
                      <div key={`rr-${y}`} className="absolute" style={{ right: '20px', top: `${y}%` }}>
                        <div className="w-3 h-3 rounded-full" style={{
                          background: 'radial-gradient(circle at 35% 35%, #3a3a5c, #1a1a2e)',
                          boxShadow: 'inset 0 1px 2px rgba(255,255,255,0.1), 0 1px 3px rgba(0,0,0,0.5)',
                        }} />
                      </div>
                    ))}
                    {/* Hinge details on right edge */}
                    {[20, 50, 80].map((y) => (
                      <div key={`rh-${y}`} className="absolute right-0" style={{ top: `${y}%`, transform: 'translateY(-50%)' }}>
                        <div className="w-2 h-12 rounded-l-sm" style={{
                          background: 'linear-gradient(-90deg, #2a2a4a, #3a3a5c, #2a2a4a)',
                          boxShadow: '-1px 0 4px rgba(0,0,0,0.5)',
                        }} />
                      </div>
                    ))}
                    {/* Center seam edge */}
                    <div className="absolute top-0 left-0 w-[3px] h-full" style={{
                      background: 'linear-gradient(180deg, #0a0a15, #2a2a4a 20%, #1a1a2e 50%, #2a2a4a 80%, #0a0a15)',
                      boxShadow: '2px 0 8px rgba(0,0,0,0.6)',
                    }} />
                    {/* Door number plate */}
                    <div className="absolute top-[15%] left-[15%] w-16 h-8 rounded-sm flex items-center justify-center" style={{
                      background: 'linear-gradient(135deg, #2a2a4a, #1e1e38)',
                      border: '1px solid rgba(139,92,246,0.15)',
                      boxShadow: 'inset 0 1px 2px rgba(0,0,0,0.3)',
                    }}>
                      <span className="text-[10px] text-purple-400/40 font-mono tracking-wider">R-01</span>
                    </div>
                  </div>
                </motion.div>

                {/* Hinge dust particles */}
                <HingeDust />

                {/* Light beam from behind the doors */}
                <motion.div
                  initial={{ opacity: 0, scaleX: 0 }}
                  animate={{ opacity: [0, 0.4, 0.2], scaleX: [0, 1, 1.5] }}
                  transition={{ delay: 1.2, duration: 2, ease: 'easeOut' }}
                  className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-full"
                  style={{
                    background: 'linear-gradient(90deg, transparent, rgba(139,92,246,0.15), rgba(167,139,250,0.2), rgba(139,92,246,0.15), transparent)',
                    filter: 'blur(20px)',
                  }}
                />
              </div>
            )}
          </AnimatePresence>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
