import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import {
  X,
  ZoomIn,
  ZoomOut,
  RotateCw,
  Download,
  Maximize2,
  Move,
} from "lucide-react";

interface ImageLightboxProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  imageUrl: string;
  title?: string;
  onDownload?: () => void;
}

export function ImageLightbox({
  open,
  onOpenChange,
  imageUrl,
  title,
  onDownload,
}: ImageLightboxProps) {
  const [zoom, setZoom] = useState(100);