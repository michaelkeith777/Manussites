import { useState } from "react";
import { AppLayout } from "@/components/AppLayout";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Heart,
  Download,
  Trash2,
  Loader2,
  ImageOff,
  Sparkles,
  Maximize2,
} from "lucide-react";
import { toast } from "sonner";
import { motion, AnimatePresence } from "framer-motion";
import { Link } from "wouter";
import { ImageLightbox } from "@/components/ImageLightbox";
import { ExportDialog } from "@/components/ExportDialog";

export default function Favorites() {
  const { isAuthenticated, loading: authLoading } = useAuth();
  const [selectedImage, setSelectedImage] = useState<any>(null);
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [exportOpen, setExportOpen] = useState(false);

  const utils = trpc.useUtils();

  const { data: favorites, isLoading } = trpc.images.list.useQuery(
    { favoritesOnly: true },
    { enabled: isAuthenticated }
  );

  const toggleFavorite = trpc.images.toggleFavorite.useMutation({
    onSuccess: () => {
      utils.images.list.invalidate();
      toast.success("Removed from favorites");
      setSelectedImage(null);
    },
    onError: (error) => {
      toast.error(error.message || "Failed to update favorite");
    },
  });

  const deleteImage = trpc.images.delete.useMutation({
    onSuccess: () => {
      utils.images.list.invalidate();
      toast.success("Image deleted");
      setSelectedImage(null);
    },
    onError: (error) => {
      toast.error(error.message || "Failed to delete image");
    },
  });

  const handleDownload = async (imageUrl: string, imageName: string) => {
    try {
      const response = await fetch(imageUrl);
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `${imageName}.png`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
      toast.success("Image downloaded!");
    } catch (error) {
      toast.error("Failed to download image");
    }
  };

  if (authLoading) {
    return (
      <AppLayout>
        <div className="flex items-center justify-center min-h-[60vh]">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      </AppLayout>
    );
  }

  if (!isAuthenticated) {
    return (
      <AppLayout>
        <div className="flex flex-col items-center justify-center min-h-[60vh] gap-4">
          <Heart className="w-16 h-16 text-muted-foreground" />
          <h2 className="text-2xl font-semibold">Sign in to view favorites</h2>
          <p className="text-muted-foreground">
            Your favorite cards will appear here after you sign in.
          </p>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="p-6 max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold flex items-center gap-3">
            <Heart className="w-8 h-8 text-red-500 fill-red-500" />
            Favorites
          </h1>
          <p className="text-muted-foreground mt-2">
            Your collection of favorite trading cards
          </p>
        </div>

        {/* Loading State */}
        {isLoading && (
          <div className="flex items-center justify-center min-h-[40vh]">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        )}

        {/* Empty State */}
        {!isLoading && (!favorites || favorites.length === 0) && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex flex-col items-center justify-center min-h-[40vh] gap-4"
          >
            <div className="w-24 h-24 rounded-full bg-muted/50 flex items-center justify-center">
              <Heart className="w-12 h-12 text-muted-foreground" />
            </div>
            <h2 className="text-xl font-semibold">No favorites yet</h2>
            <p className="text-muted-foreground text-center max-w-md">
              Start adding cards to your favorites by clicking the heart icon on
              any card in your gallery.
            </p>
            <Link href="/gallery">
              <Button className="mt-4">
                <Sparkles className="w-4 h-4 mr-2" />
                Browse Gallery
              </Button>
            </Link>
          </motion.div>
        )}

        {/* Favorites Grid */}
        {!isLoading && favorites && favorites.length > 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4"
          >
            <AnimatePresence>
              {favorites.map((image, index) => (
                <motion.div
                  key={image.id}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  transition={{ delay: index * 0.05 }}
                >
                  <Card
                    className="group cursor-pointer overflow-hidden hover:ring-2 hover:ring-primary/50 transition-all"
                    onClick={() => setSelectedImage(image)}
                  >
                    <CardContent className="p-0 relative aspect-[2/3]">
                      {image.imageUrl ? (
                        <img
                          src={image.imageUrl}
                          alt={image.prompt || "Favorite card"}
                          className="w-full h-full object-cover"
                          loading="lazy"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center bg-muted">
                          <ImageOff className="w-8 h-8 text-muted-foreground" />
                        </div>
                      )}
                      {/* Hover Overlay */}
                      <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                        <Button
                          size="icon"
                          variant="secondary"
                          className="h-8 w-8"
                          onClick={(e) => {
                            e.stopPropagation();
                            if (image.imageUrl) {
                              handleDownload(
                                image.imageUrl,
                                `zelvari-card-${image.id}`
                              );
                            }
                          }}
                        >
                          <Download className="w-4 h-4" />
                        </Button>
                        <Button
                          size="icon"
                          variant="secondary"
                          className="h-8 w-8"
                          onClick={(e) => {
                            e.stopPropagation();
                            toggleFavorite.mutate({ imageId: image.id });
                          }}
                        >
                          <Heart className="w-4 h-4 fill-red-500 text-red-500" />
                        </Button>
                      </div>
                      {/* Favorite Badge */}
                      <div className="absolute top-2 right-2">
                        <Heart className="w-5 h-5 fill-red-500 text-red-500 drop-shadow-lg" />
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </AnimatePresence>
          </motion.div>
        )}

        {/* Image Detail Dialog */}
        <Dialog
          open={!!selectedImage}
          onOpenChange={(open) => !open && setSelectedImage(null)}
        >
          <DialogContent className="max-w-3xl bg-background text-foreground">
            <DialogHeader>
              <DialogTitle>Card Details</DialogTitle>
            </DialogHeader>
            {selectedImage && (
              <div className="space-y-4">
                <div className="relative aspect-[2/3] max-h-[60vh] mx-auto overflow-hidden rounded-lg">
                  {selectedImage.imageUrl ? (
                    <img
                      src={selectedImage.imageUrl}
                      alt={selectedImage.prompt || "Card"}
                      className="w-full h-full object-contain"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center bg-muted">
                      <ImageOff className="w-12 h-12 text-muted-foreground" />
                    </div>
                  )}
                </div>

                {selectedImage.prompt && (
                  <div className="bg-muted/50 rounded-lg p-3">
                    <p className="text-sm text-muted-foreground">Prompt</p>
                    <p className="text-sm mt-1">{selectedImage.prompt}</p>
                  </div>
                )}

                <div className="flex flex-wrap gap-2 justify-center">
                  <Button
                    variant="outline"
                    onClick={() => setLightboxOpen(true)}
                  >
                    <Maximize2 className="w-4 h-4 mr-2" />
                    View Larger
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => setExportOpen(true)}
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Export
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => toggleFavorite.mutate({ imageId: selectedImage.id })}
                    disabled={toggleFavorite.isPending}
                  >
                    {toggleFavorite.isPending ? (
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    ) : (
                      <Heart className="w-4 h-4 mr-2 fill-red-500 text-red-500" />
                    )}
                    Remove from Favorites
                  </Button>
                  <Button
                    variant="destructive"
                    onClick={() => {
                      if (confirm("Are you sure you want to delete this card?")) {
                        deleteImage.mutate({ imageId: selectedImage.id });
                      }
                    }}
                    disabled={deleteImage.isPending}
                  >
                    {deleteImage.isPending ? (
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    ) : (
                      <Trash2 className="w-4 h-4 mr-2" />
                    )}
                    Delete
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>

        {/* Image Lightbox */}
        {selectedImage?.imageUrl && (
          <ImageLightbox
            open={lightboxOpen}
            onOpenChange={setLightboxOpen}
            imageUrl={selectedImage.imageUrl}
            title={selectedImage.prompt || "Favorite Card"}
          />
        )}

        {/* Export Dialog */}
        {selectedImage?.imageUrl && (
          <ExportDialog
            open={exportOpen}
            onOpenChange={setExportOpen}
            imageUrl={selectedImage.imageUrl}
            imageName={`zelvari-favorite-${selectedImage.id}`}
          />
        )}
      </div>
    </AppLayout>
  );
}
